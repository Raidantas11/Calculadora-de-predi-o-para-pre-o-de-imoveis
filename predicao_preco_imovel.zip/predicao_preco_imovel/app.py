from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)


model = joblib.load("modelo_lr_.pkl")

@app.route("/", methods=["GET", "POST"])
def index():
    previsao = None

    if request.method == "POST":
        try:
            metros = float(request.form.get("metros"))
            quartos = float(request.form.get("quartos"))
            banheiros = float(request.form.get("banheiros"))
            ano = float(request.form.get("ano"))
            lote = float(request.form.get("lote"))
            garagem = float(request.form.get("garagem"))
            qualidade = float(request.form.get("qualidade"))

            features = np.array([[metros, quartos, banheiros, ano, lote, garagem, qualidade]])

            preco_previsto = model.predict(features)[0]
            previsao = f"${float(preco_previsto):,.2f}"


        except Exception as e:
            previsao = f"Erro: {e}"

    return render_template("index.html", previsao=previsao)

if __name__ == "__main__":
    app.run(debug=True)
